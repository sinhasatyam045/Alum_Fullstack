import React from "react";

const ActivitiesSection = () => {
  return <div>activitiesSection</div>;
};

export default ActivitiesSection;
