import React from "react";

const ArticlesSection = () => {
  return <div>articlesSection</div>;
};

export default ArticlesSection;
