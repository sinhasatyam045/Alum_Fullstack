import React from 'react';

const ScreenFour = () => {
    return (
        <div>
            {/* Your component code goes here */}
        </div>
    );
};

export default ScreenFour;
